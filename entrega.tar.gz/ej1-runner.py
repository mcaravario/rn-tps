#!/bin/python3
from tp1.ej1.ej1 import *
