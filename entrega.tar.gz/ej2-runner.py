#!/bin/python3
from tp1.ej2.ej2 import *
