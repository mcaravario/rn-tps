#!/usr/bin/python3
DB_TRAINING = 'data/tp2_training_dataset.csv'
